runtime per image [s] : 0.12
CPU[1] / GPU[0] : 0
Extra Data [1] / No Extra Data [0] : 1
Other description : Solution based on an inception resnet v2 network pretrained on ImageNet and a Convolutional Transformer post Network. Distorted images MOS are regressed using a Mean Squared Error loss. The method was trained on the PIPAL dataset training subset.
Full-Reference [1] / Non-Reference [0] : 1